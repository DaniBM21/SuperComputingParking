# Parallel Python

Visit http://www.parallelpython.com for up-to-date documentation, examples and support forums.

**Installation**

    python setup.py install

**Local documentation**

    <htmlviewer> pydoc.html
